<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form in HTML and CSS </title>
  <link rel="stylesheet" href="style.css">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <style>
  {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "poppins", sans-serif;
}

body {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: url('assets/imgs/Img.jpeg') no-repeat;
  background-size: cover;
  background-position: center;
}

.wrapper {
  width: 420px;
  background: transparent;
  border: 2px solid rgba(100, 100, 100, .2);
  backdrop-filter: blur(20px);
  box-shadow: 0 0 10px rgba(0, 0, 0, .2);
  color: black;
  border-radius: 10px;
  padding: 40px 50px;
}

.wrapper h1 {
  font-size: 36px;
  text-align: center;
}

.wrapper .input-box {
  position: relative;
  width: 100%
  height: 50px;
  margin: 30px 0;
}

.input-box input {
  width: 100%;
  height: 100%;
  background: transparent;
  border: none;
  outline: none;
  border: 3px solid rgba(255, 255, 255, .2);
  border-radius: 40px;
  font-size: 20px;
  color: black;
  padding: 10px 10px 15px 15px;
}

.input-box input: :placeholder {
  color: black;
}

.input-box i {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 20px;
}

.wrapper .remember-forgot {
  display: flex;
  justify-content: space-between;
  font-size: 20px;
  margin: -20px 0 20px;
}
.input-group {
    margin-bottom: 15px;
}

.input-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.input-group input, .input-group select {
    width: 100%;
    padding: 10px;
    Background-color: #c8a2c8;
    border: 1px;
    border-radius: 5px;
}
.remember-forgot label input {
  accent-color: #fff;
  margin-right: 8px;
}

.remember-forgot a {
  color: black;
  text-decoration: none;
}

.remember-forgot a:hover {
  text-decoration: underline;
  Position: center;
}

.wrapper .btn {
  width: 100%;
  height: 45px;
  background: #fff;
  border: none;
  outline: none;
  border-radius: 40px;
  border-shadow: 0 0 10px rgba(0, 0, 0, .1);
  cursor: pointer;
  font-size: 16px;
  color: #333;
  font-weight: 600;
}
  </style>
</head>
<body>

  <div class="wrapper">
         <h1>Admin Login</h1>
        <form  name="form" action="adminconc.php" method="post">
	 <div class="input-box">
	     <input type="text" name="user" placeholder="username" required>
             <i class='bx bxs-user'></i>
         
         </div>
  <div class="input-box">
	     <input type="password" name="pass" placeholder="password" required>
             <i class='bx bxs-lock-alt'></i></div>
<br>
  <div class="remember-forgot"> 

      <label><input type="checkbox"> Remember me</label>
      <a href="#">Forgot password?</a>
</br>
	 </div>
<button type="submit" name="submit"  value="submit" class="btn" >Login</button>
</form>    
    </div>
</body>
</html>
