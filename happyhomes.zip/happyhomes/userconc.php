<?php
    $servername="localhost";
    $username="root";
    $password="";
    $db_name="happyhomes";
    $conn = new mysqli($servername, $username, $password, $db_name);
    if($conn->connect_error)
  {
    die("connection failed".$conn->connect_error);
  }

  if (isset($_POST["submit"])) {
        $username = $_POST['user'];
        $password = $_POST['pass'];
    
        $sql = "SELECT * FROM reg where username = '$username' and password = '$password'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        $count = mysqli_num_rows($result);
         if($result->num_rows > 0) 
         {
            echo "Login Successful"; 
            header("Location:index.php");
          exit();
         }
         else{
            echo '<script>
            window.location.href = "buyer.php";
            alert("Login failed. Invalid Username or Password")
            </script>';
            }
        }
      
$conn->close();
?>
